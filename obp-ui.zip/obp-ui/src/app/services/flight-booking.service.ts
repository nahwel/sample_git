import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FlightBookingService {

  private apiDomain = environment.API_DOMAIN;

  constructor(private http: HttpClient) { }

  bookFlight(name: string, email: string, phoneNumber: string, origin: string, destination: string, details: string, eta: string): Observable<any> {
    const body = {
      name: name,
      email: email,
      phoneNumber: parseInt(phoneNumber),
      origin: origin,
      destination: destination,
      details: details,
      eta: this.reformatDate(eta)
    };
    return this.http.post(this.apiDomain + '/obp-api/flight-bookings', body);
  }

  deleteFlight(id: number) {
    return this.http.delete(this.apiDomain + '/obp-api/flight-bookings/' + id);
  }

  getAllFlights(): Observable<any> {
    return this.http.get(this.apiDomain + '/obp-api/flight-bookings');
  }

  private reformatDate(date: any): string {
    return `${date.year}-${date.month}-${date.day}`;
  }
}
