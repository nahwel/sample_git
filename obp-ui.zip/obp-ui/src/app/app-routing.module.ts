import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateBookingComponent } from './components/create-booking/create-booking.component';
import { ViewBookingComponent } from './components/view-booking/view-booking.component';

const routes: Routes = [
  { path: 'create-booking', component: CreateBookingComponent },
  { path: 'view-bookings', component: ViewBookingComponent },
  { path: '', redirectTo: 'create-booking', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
