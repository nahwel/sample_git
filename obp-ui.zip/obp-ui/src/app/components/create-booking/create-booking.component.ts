import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbCalendar, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { FlightBookingService } from 'src/app/services/flight-booking.service';

@Component({
  selector: 'app-create-booking',
  templateUrl: './create-booking.component.html',
  styleUrls: ['./create-booking.component.scss']
})
export class CreateBookingComponent implements OnInit {

  bookingForm = new FormGroup({
    name: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required, Validators.email]),
    phoneNumber: new FormControl('', [Validators.required, Validators.pattern("^[0-9]*$")]),
    origin: new FormControl('', [Validators.required]),
    destination: new FormControl('', [Validators.required]),
    details: new FormControl('', [Validators.required]),
    eta: new FormControl('', [Validators.required])
  });
  isFormSubmitted: boolean = false;

  // model: NgbDateStruct;
	date: { year: number; month: number };
  
  constructor(
    private flightBookingService: FlightBookingService,
    private router: Router
    ) { }

  ngOnInit(): void {
  }

  submit(): void {
    this.isFormSubmitted = true;
    this.bookingForm.updateValueAndValidity();
    if (!this.bookingForm.invalid) {
      this.flightBookingService.bookFlight(this.returnBlankStringIfNull(this.bookingForm.controls['name'].value),
        this.returnBlankStringIfNull(this.bookingForm.controls['email'].value),
        this.returnBlankStringIfNull(this.bookingForm.controls['phoneNumber'].value),
        this.returnBlankStringIfNull(this.bookingForm.controls['origin'].value),
        this.returnBlankStringIfNull(this.bookingForm.controls['destination'].value),
        this.returnBlankStringIfNull(this.bookingForm.controls['details'].value),
        this.returnBlankStringIfNull(this.bookingForm.controls['eta'].value))
      .subscribe((data: any) => {
        window.alert('SUCCESS!');
        this.router.navigate(['/view-bookings']);
      });
    }
  }

  private returnBlankStringIfNull(input: string | null): string {
    if (!input) {
      return "";
    }
    return input;
  }
}
