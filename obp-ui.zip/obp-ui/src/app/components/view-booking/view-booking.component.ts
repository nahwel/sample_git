import { Component, OnInit } from '@angular/core';
import { FlightBookingService } from 'src/app/services/flight-booking.service';

@Component({
  selector: 'app-view-booking',
  templateUrl: './view-booking.component.html',
  styleUrls: ['./view-booking.component.scss']
})
export class ViewBookingComponent implements OnInit {

  flightBookings: any[];

  constructor(private flightBookingService: FlightBookingService) { }

  ngOnInit(): void {
    this.initFlightBookings();
  }

  delete(id: number) {
    this.flightBookingService.deleteFlight(id).subscribe((data: any) => {
      window.alert("Flight deleted!");
      this.initFlightBookings();
    });
  }

  private initFlightBookings() {
    this.flightBookingService.getAllFlights().subscribe((data: any) => {
      this.flightBookings = data;
    });
  }
}
